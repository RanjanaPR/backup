package com.example.demo;

public class Emplyoee {
	public Emplyoee() {
		super();
	}
	
		public Emplyoee(int empId, String name, String designation, int salary) {
		super();
		this.empId = empId;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
	}
		private int empId;
		private String name;
		private String designation;
		private int salary;
		
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int i) {
			this.empId = i;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}

		@Override
		public String toString() {
			return "Emplyoee [empId=" + empId + ", name=" + name + ", designation=" + designation + ", salary=" + salary
					+ "]";
		}
}
