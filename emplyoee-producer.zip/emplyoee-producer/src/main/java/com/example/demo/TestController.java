package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class TestController {
	@RequestMapping(value="/Emplyoee", method=RequestMethod.GET)
public Emplyoee firstpage() {
	Emplyoee emp1=new Emplyoee();
	emp1.setName("ranjana");
	emp1.setDesignation("architect");
	emp1.setEmpId(33456);
	emp1.setSalary(355466);
	return emp1;
	
			
}
}
