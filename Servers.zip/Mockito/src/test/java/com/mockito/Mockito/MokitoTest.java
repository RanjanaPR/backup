package com.mockito.Mockito;

import static org.junit.Assert.*;

import org.junit.Test;

public class MokitoTest {

	@Test
	public void test() {
		assertTrue(false);
	}

}
