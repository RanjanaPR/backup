package com.mockito.Mockito.stubTest;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.mockito.Implementation.ToDoBuissnessImpl;
import com.mockito.Mockito.ToDoService;
import com.mockito.Mockito.ToDoServiceStub;

public class RetreiveUserUsingStubTest {
	@Test
	public void testToDoImplUsingStub() {
	ToDoService todoService=new ToDoServiceStub();
	ToDoBuissnessImpl todoImpl=new ToDoBuissnessImpl(todoService);
	List<String> toDoList=todoImpl.retrieveToDorelatedToSpring("rach");

           assertEquals(3,toDoList.size());
	}
}
