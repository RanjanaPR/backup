package com.mockito.Mockito;

import java.util.Arrays;
import java.util.List;

public class ToDoServiceStub implements ToDoService {

	public List<String> retrieveToDo(String user) {
		return Arrays.asList("Spring using mvc","Spring hibernate", "Ranju,Spring Yashu");
	}

}
