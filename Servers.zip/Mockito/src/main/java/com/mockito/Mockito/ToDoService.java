package com.mockito.Mockito;

import java.util.List;

public interface ToDoService {

public List<String> retrieveToDo(String user);	
}
