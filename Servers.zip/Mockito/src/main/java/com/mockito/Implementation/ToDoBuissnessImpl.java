package com.mockito.Implementation;

import java.util.ArrayList;
import java.util.List;

import com.mockito.Mockito.ToDoService;

public class ToDoBuissnessImpl {
	private ToDoService toDoService;

	public ToDoBuissnessImpl(ToDoService toDoService) {
		super();
		this.toDoService = toDoService;
	}
	
	public List<String> retrieveToDorelatedToSpring(String user){
		List<String> filterToDo=new ArrayList<String>();
		List<String> toDos=toDoService.retrieveToDo(user);
		
		for(String toDo:toDos) {
			if(toDo.contains("Spring")) {
				filterToDo.add(toDo);
			}
		}
		return filterToDo;
	}

}
