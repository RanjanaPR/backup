package com.BankAccount.Pojo;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.BankAccount.Pojo.BankAccPojo;

@Repository
public interface BankAccRepository extends MongoRepository<BankAccPojo, ObjectId>{
	public BankAccPojo findBy_id(ObjectId _id);
	
}
