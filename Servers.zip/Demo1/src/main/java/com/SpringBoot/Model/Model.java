package com.SpringBoot.Model;

public class Model {

}
