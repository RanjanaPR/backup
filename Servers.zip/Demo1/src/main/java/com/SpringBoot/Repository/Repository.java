package com.SpringBoot.Repository;

public class Repository {

}
